  <!-- ***********************************************************************************
  Page Name  : current page name 
  Author     : Your Name 
  Your URL   : ocelot-aul.fiu/~__________
  Course     : CGS 4854 session, date, and time
  Program #  : Assignment #
  Purpose    : Describe what this page does 

  Due Date   : MM/DD/YYYY 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ your full name }..........
  ************************************************************************************* -->

<!DOCTYPE html>   <!-- declaration used in HTML 5. Tells browsers that this is HTML 5 -->

<html>

  <body>
    
    <!--h3>this is delete.phd</h3-->
             
                  
    <?php
                   
       $record = "RECORD ". $Telephone." DELETED";
         
       $found = $_POST['found']; 
       //echo "delete  found = [" . $found . "]<br>";
        
       // sql to delete a record
       $sql="DELETE FROM customers WHERE Telephone='$Telephone'";
         
       $Telephone=trim($Telephone);
          
       //     if(strlen($Telephone)>0)           
       if (  ( strlen(trim($found)) > 0 ) && ($found == $Telephone) )
       { 
                      
          if (mysqli_query($connection, $sql)) 
          {
             //echo "Record deleted successfully found = {".$found."}";
             $message ="<span style=\"color: red;\">RECORD $found DELETE</span><br\>";
             $found=""; //this clear the flag for record found to be able to modify 
          }         
          else 
          {
             $message = "Error deleting record: " . mysqli_error($connection); 
          }
          
       }   
       else
       {
          $message ="<span style=\"color: red;\">RECORD NOT DELETED<BR>Telephone CAN NOT BE EMPTY</span><br\>";
       }
       
    ?>
                           
  </body>
                    
</html>
