<!-- ***********************************************************************************
  Page Name  : current page name 
  Author     : Your Name 
  Your URL   : ocelot-aul.fiu/~__________
  Course     : CGS 4854 session, date, and time
  Program #  : Assignment #
  Purpose    : Describe what this page does 
 
  Due Date   : MM/DD/YYYY 
 
  Certification: 
 
  I hereby certify that this work is my own and none of it is the work of any other person. 
 
  ..........{ your full name }..........
  ************************************************************************************* -->
 
<!DOCTYPE html>   <!-- declaration used in HTML 5. Tells browsers that this is HTML 5 -->
 
<html>
  <head>
    <title>ControllerPgm3</title>
  </head>
          
  <body>
      
    <?php
                     
       //connecting to mysql 
       //echo "<h3>I am going to connect to mySql";
 
       //                                server               user      password  database     
       $connection = mysqli_connect("ocelot.aul.fiu.edu","mhacc001","6262270","fall22_mhacc001");
       if (mysqli_connect_errno())
       {
          echo "Failed to connect to MySQL: " . mysqli_connect_error();
       }
       else
       {  
          //echo "<br>I have connected to mySql<br>";            
             
          // Change database to another name if needed
             
          $dbName="fall22_mhacc001"; 
          $db_selected = mysqli_select_db( $connection, $dbName );
                      
          if (!$db_selected)
          {
             die( $dbName . ' does not exist, can\'t use it ' . mysqli_error());
          }
          else
          {
             //echo "I selected database : " . $db_selected . " " . $dbName . "<br></h3>" ;
                   
             //access to a table                    
             $tableName = "customers";
                      
             $query = mysqli_query( $connection, "SELECT * FROM $tableName" );
//if table does not exist, create it 
             if(!$query)
             {
              	echo "The ".$tableName." does not exists<br>";
                        
                echo "<br>Creating table : ".$tableName."<br>";
                       
                $sql = "CREATE TABLE ".$tableName."(
                        Telephone VARCHAR(20) NOT NULL,
                        PRIMARY KEY(Telephone),
                        FirstName VARCHAR(30),
                        LastName VARCHAR(30),
                        Email VARCHAR(30),
                        Type VARCHAR(8),
                        Ship VARCHAR(10),
                        IT VARCHAR(2), 
                        Cambodian  VARCHAR(2),
                        Indian  VARCHAR(8),
                        Malaysian  VARCHAR(11),
                        Others VARCHAR(30),
                        SpecialNeeds VARCHAR(200)
                        )";
                                
                $result = mysqli_query( $connection, $sql );
                         
                //confirm table creation
                if ($result)
                {
                   echo "table ". $tableName." created<br>";
                }
                else
                {
                   die ("Can\'t create ". $tableName." ". mysqli_error() );
                }
                     
             }//if(!$query) if table does not exist, create it 
                        
          }//end if (!$db_selected) connecting to db
                
       }//end if (mysqli_connect_errno()) connecting to mysql
 
                    
       //extract the data inputed by the user creating global php fields 
       $Telephone    = $_POST['Telephone'];
       $FirstName    = $_POST['FirstName'];
       $LastName     = $_POST['LastName'];
       $Email        = $_POST['Email'];
       $Type          = $_POST['Type'];
       $Ship       = $_POST['Ship'];
       $IT           = $_POST['IT'];
       $Malaysian           = $_POST['Malaysian'];
       $Indian     = $_POST['Indian'];
       $Cambodian  = $_POST['Cambodian'];
       $Others       = $_POST['Others'];
       $SpecialNeeds = $_POST['SpecialNeeds'];            
                 
       $found = $_POST['found']; 
/*      
       //verify that the data entered by the user is being received
       echo $Telephone."<br>"; 
       echo $FirstName."<br>";  
       echo $LastName."<br>";  
       echo $Email."<br>";  
       echo $Age."<br>";  
       echo $Gender."<br>";  
       echo $IT."<br>";  
       echo $CS."<br>";  
       echo $Robotics."<br>";  
       echo $Engineering."<br>";  
       echo $Others."<br>";  
       echo $SpecialNeeds."<br>";  
*/                  
               
                        
       if ( $_POST['Find'] )
       { 
          include('Find.php');
          include( "Program3.php" );
       }
       else if ( $_POST['Save'] )
       { 
          include('save.php');
          include( "Program3.php" );
       }
       else if ( $_POST['Modify'] )
       {  
          include('Modify.php');
          include( "Program3.php" );
       }
       else if ( $_POST['Delete'] )
       { 
          include('Delete.php');
          include( "Program3.php" );
       }
       else if ( $_POST['Clear'] )
       {
          include('Clear.php');
          include( "Program3.php" );
       }
       else
       { 
          echo "<br><h1> you pressed UNKOWN button</h1>";   
       }
mysqli_close($connection); 
 
       include( "Program3.php" );
        
    ?>//end controler.php
                 
  </body>
 
</html>
 

