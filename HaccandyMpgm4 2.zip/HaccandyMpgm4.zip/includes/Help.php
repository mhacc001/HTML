<!-- ***************************************************************************************
  Page Name  : includes/help.php
  Author     : Marie Haccandy
  Your URL   : ocelot-aul.fiu/~mhacc001
  Course     : WEB Online - CGS 4854, Fall 2022
  Program #4 : Assignment #4
  Purpose    : Pop up help

  Due Date   : 11/24/2022

  Certification:

  I hereby certify that this work is my own and none of it is the work of any other person.

  ..........Marie Haccandy..........
 **************************************************************************************** -->

<!DOCTYPE html>              
<html>
<head>
  <title>Help Marie Haccandy</title>
<body onload="help()">

<script>

function help()
{
   // Open a new window at a specific location
   var myWindow = window.open("", "Help","width=500, height=600, scrollbars=yes,resizable=yes, left=870, top=50"); 
     	
   // Display the purpose of each button on the form in the newly opened window
        myWindow.document.write("<head>");
        myWindow.document.write("<title>Help</title>");
        myWindow.document.write("</head>");
        myWindow.document.write("<div>");
        myWindow.document.write("<div><h1 style='color:blue'>* HELP * </h1></div>");
        myWindow.document.write("<hr>");
        myWindow.document.write("<div> <h2><span style='color:purple'>Buttons Purpose</span></h2></div>");
        myWindow.document.write("<div>");
        myWindow.document.write("<ul style='list-style-type:circle'>");
        myWindow.document.write("<li>\n <h3 style='color:green'>FIND.</h3>");
        myWindow.document.write("<div>Used to find a client's record by inputting their Telephone number and pressing the FIND button, it then passes the telephone (primary key), using POST, to the table.</div><br></li>");
        myWindow.document.write("<div>If the clients record is found, the fields on the Data page will be filled with information about the user, and a message will appear, stating <span style='color:red'>*RECORD FOUND</span> . Otherwise, a message will appear stating <span style='color:red'>*RECORD NOT FOUND</span></div>");
        myWindow.document.write("<li>\n <h3 style='color:green'>SAVE.</h3>");
        myWindow.document.write("<div>Use the Save button to add client's information to the database.The information will be stored in the table, and a message will appear stating <span style='color:red'>RECORD ADDED</span>. Otherwise, if the information has previously been entered, a message will appear, stating <span style='color:red'>RECORD ALREADY EXISTS.</span></div><br></li>");

        //myWindow.document.write("<br>");
        myWindow.document.write("<li>\n <h3 style='color:green'>MODIFY.</h3>");
        myWindow.document.write("<div>Use the Modify button to edit an existing client record on the table. The client's telephone must be found first, so the data can be changed.</div><br></li>");
        myWindow.document.write("<div>To modify a client's info, follow these steps:</div>");
        myWindow.document.write("<ol class='popup-list' type='1'>");
        myWindow.document.write("<li>Enter the client's Telephone number that you want update.</li>");
        myWindow.document.write("<li>Then, press the <b>Find button</b> to search for the record .</li>");
        myWindow.document.write("<li>Next, change the data you want update</li>");
        myWindow.document.write("<li>Finally, press the <b>Modify button </b> to store client's modified information.</li>");
        myWindow.document.write("</ol>");
    
        // myWindow.document.write("<br>");
        myWindow.document.write("<li><h3 style='color:green'>DELETE.</h3>");
        myWindow.document.write("<div>Use the Delete button to delete client's existing telephone . To do that, their telephone must first be found, then the data can be deleted from the database.</div><br></li>");
        myWindow.document.write("<li><h3 style='color:green'>CLEAR.</h3>");
        myWindow.document.write("<div>The Clear button clears the data from the fields on the Data page.</div><br></li>");
        myWindow.document.write("<li><h3 style='color:green'>HELP.</h3>");
        myWindow.document.write("<div> Help button to discover the purpose and functionality of the buttons, using JavaScript.</div><br></li>");
        myWindow.document.write("<li><h3 style='color:green'>ABOUT.</h3>");
        myWindow.document.write("<div> About button to describe the web pages purpose.</div><br></li>");
        myWindow.document.write("</ul>");
        myWindow.document.write("</div>");
        
      }
      
    </script>

  </body>
</html>
