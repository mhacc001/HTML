document.addEventListener('DOMContentLoaded', function() {
    const citySelect = document.getElementById('city-select');
    const getWeatherBtn = document.getElementById('get-weather');
    const weatherResults = document.getElementById('weather-results');
    const loadingElement = document.querySelector('.loading');
    const errorElement = document.querySelector('.error');
    const celsiusBtn = document.getElementById('celsius-btn');
    const fahrenheitBtn = document.getElementById('fahrenheit-btn');
    
    let currentUnit = 'celsius';
    let currentWeatherData = null;
    let currentCityName = '';
    
    // Weather icon mapping - UPDATED PATHS FOR ALL ICONS
    const weatherIcons = {
        'clearday': 'images/clear.png',
        'clearnight': 'images/clear.png',
        'pcloudyday': 'images/pcloudy.png',
        'pcloudynight': 'images/pcloudy.png',
        'mcloudyday': 'images/mcloudy.png',
        'mcloudynight': 'images/mcloudy.png',
        'cloudyday': 'images/cloudy.png',
        'cloudynight': 'images/cloudy.png',
        'humidday': 'images/humid.png',
        'humidnight': 'images/humid.png',
        'lightrainday': 'images/lightrain.png',
        'lightrainnight': 'images/lightrain.png',
        'oshowerday': 'images/oshower.png',
        'oshowernight': 'images/oshower.png',
        'ishowerday': 'images/ishower.png',
        'ishowernight': 'images/ishower.png',
        'lightsnowday': 'images/lightsnow.png',
        'lightsnownight': 'images/lightsnow.png',
        'rainday': 'images/rain.png',
        'rainnight': 'images/rain.png',
        'snowday': 'images/snow.png',
        'snownight': 'images/snow.png',
        'rainsnowday': 'images/rainsnow.png',
        'rainsnownight': 'images/rainsnow.png',
        'tsrain': 'images/tsrain.png',
        'tstorm': 'images/tstorm.png',
        'windy': 'images/windy.png'
    };

    // Temperature conversion functions
    function celsiusToFahrenheit(c) {
        return Math.round((c * 9/5) + 32);
    }
    
    function convertTemps(data, toUnit) {
        if (toUnit === 'fahrenheit') {
            return data.map(day => ({
                ...day,
                temp2m: {
                    max: celsiusToFahrenheit(day.temp2m.max),
                    min: celsiusToFahrenheit(day.temp2m.min)
                }
            }));
        }
        return data; // Already in celsius
    }
    
    // Unit toggle functionality
    celsiusBtn.addEventListener('click', function() {
        if (currentUnit !== 'celsius') {
            currentUnit = 'celsius';
            celsiusBtn.classList.add('active');
            fahrenheitBtn.classList.remove('active');
            if (currentWeatherData) {
                displayWeather(currentWeatherData, currentCityName);
            }
        }
    });
    
    fahrenheitBtn.addEventListener('click', function() {
        if (currentUnit !== 'fahrenheit') {
            currentUnit = 'fahrenheit';
            fahrenheitBtn.classList.add('active');
            celsiusBtn.classList.remove('active');
            if (currentWeatherData) {
                displayWeather(currentWeatherData, currentCityName);
            }
        }
    });

    // Load cities from CSV file
    function loadCities() {
        console.log('Attempting to load city_coordinates.csv...');
        fetch('city_coordinates.csv')
            .then(response => {
                console.log('CSV fetch response status:', response.status, response.statusText);
                if (!response.ok) {
                    throw new Error(`Failed to load city data: ${response.status} ${response.statusText}`);
                }
                return response.text();
            })
            .then(csvData => {
                console.log('CSV data fetched successfully. Length:', csvData.length);
                console.log('First 100 characters of CSV data:', csvData.substring(0, 100));

                const cities = parseCSV(csvData);
                console.log('Parsed cities count:', cities.length);
                if (cities.length > 0) {
                    populateCityDropdown(cities);
                    console.log('City dropdown populated.');
                } else {
                    throw new Error('No valid cities found in CSV after parsing.');
                }
            })
            .catch(error => {
                console.error('Error loading or parsing cities from CSV:', error);
                // Fallback to default cities if CSV fails
                const defaultCities = [
                    {lat: 52.367, lon: 4.904, city: "Amsterdam", country: "Netherlands"},
                    {lat: 39.933, lon: 32.859, city: "Ankara", country: "Turkey"},
                    {lat: 56.134, lon: 12.945, city: "Åstorp", country: "Sweden"},
                    {lat: 37.983, lon: 23.727, city: "Athens", country: "Greece"},
                    {lat: 51.507, lon: -0.127, city: "London", country: "England"},
                    {lat: 48.856, lon: 2.352, city: "Paris", country: "France"},
                    {lat: 41.902, lon: 12.496, city: "Rome", country: "Italy"}
                ];
                populateCityDropdown(defaultCities);
                showError('Using default cities. Could not load city data from CSV.');
            });
    }

    // Parse CSV data
    function parseCSV(csv) {
        const lines = csv.split('\n').filter(line => line.trim() !== '');
        const cities = [];
        console.log('Parsing CSV with', lines.length, 'lines.');
        
        // Check if first line is header (if it contains 'lat' or 'lon' or 'city' in a likely header format)
        const hasHeader = lines.length > 0 && (
            lines[0].toLowerCase().includes('lat') &&
            lines[0].toLowerCase().includes('lon') &&
            lines[0].toLowerCase().includes('city')
        );
        const startLine = hasHeader ? 1 : 0;
        console.log('CSV has header:', hasHeader);
        
        for (let i = startLine; i < lines.length; i++) {
            const parts = lines[i].split(',');
            if (parts.length >= 4) {
                const lat = parseFloat(parts[0].trim());
                const lon = parseFloat(parts[1].trim());
                const city = parts[2].trim();
                const country = parts[3].trim();
                
                if (!isNaN(lat) && !isNaN(lon) && city && country) {
                    cities.push({ lat, lon, city, country });
                } else {
                    console.warn(`Skipping malformed CSV line ${i + 1}:`, lines[i]);
                }
            } else {
                console.warn(`Skipping incomplete CSV line ${i + 1}:`, lines[i]);
            }
        }
        return cities;
    }

    // Populate city dropdown
    function populateCityDropdown(cities) {
        citySelect.innerHTML = '<option value="">Select a city</option>';
        
        // Sort cities alphabetically by city name
        cities.sort((a, b) => a.city.localeCompare(b.city));
        
        // Group by country
        const countries = {};
        cities.forEach(city => {
            if (!countries[city.country]) {
                countries[city.country] = [];
            }
            countries[city.country].push(city);
        });
        
        // Add cities to dropdown, grouped by country
        Object.keys(countries).sort().forEach(country => {
            const optgroup = document.createElement('optgroup');
            optgroup.label = country;
            
            countries[country].forEach(city => {
                const option = document.createElement('option');
                option.value = `${city.lat},${city.lon}`;
                option.textContent = `${city.city}`;
                optgroup.appendChild(option);
            });
            
            citySelect.appendChild(optgroup);
        });
    }

    // Load cities when page loads
    loadCities();

    // Fetch weather data
    getWeatherBtn.addEventListener('click', fetchWeather);
    
    function fetchWeather() {
        const selectedCity = citySelect.value;
        
        if (!selectedCity) {
            showError('Please select a city');
            return;
        }
        
        clearWeatherResults();
        loadingElement.style.display = 'block';
        errorElement.style.display = 'none';
        
        const [lat, lon] = selectedCity.split(',');
        currentCityName = citySelect.options[citySelect.selectedIndex].text;
        
        // Try direct API first, then fallback to CORS proxy
        const apiUrls = [
            `https://www.7timer.info/bin/api.pl?lon=${lon}&lat=${lat}&product=civillight&output=json`,
            `https://cors-anywhere.herokuapp.com/https://www.7timer.info/bin/api.pl?lon=${lon}&lat=${lat}&product=civillight&output=json`
        ];
        
        tryApiCall(apiUrls, 0);
    }
    
    function tryApiCall(urls, index) {
        if (index >= urls.length) {
            showError('All API attempts failed. Using sample data.');
            displaySampleData(); // Fallback to dynamic sample data
            return;
        }
        
        fetch(urls[index], {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => {
            if (!response.ok) throw new Error('API error');
            return response.json();
        })
        .then(data => {
            if (data.dataseries) {
                currentWeatherData = data.dataseries;
                displayWeather(currentWeatherData, currentCityName);
            } else {
                throw new Error('Invalid data format');
            }
        })
        .catch(error => {
            console.log(`API attempt ${index + 1} failed, trying next...`);
            tryApiCall(urls, index + 1);
        });
    }
    
    function displayWeather(forecastData, cityName) {
        clearWeatherResults();
        
        // Convert temperatures if needed
        const displayData = currentUnit === 'fahrenheit' 
            ? convertTemps(forecastData, 'fahrenheit') 
            : forecastData;
        
        const weatherDisplay = document.createElement('div');
        weatherDisplay.className = 'weather-display';
        
        const cityHeader = document.createElement('h2');
        cityHeader.textContent = `7-Day Forecast for ${cityName}`;
        cityHeader.style.textAlign = 'center';
        cityHeader.style.width = '100%';
        cityHeader.style.marginBottom = '20px';
        weatherResults.appendChild(cityHeader);
        
        displayData.forEach(day => {
            const dateStr = day.date.toString();
            const year = dateStr.substring(0, 4);
            const month = dateStr.substring(4, 6);
            const dayOfMonth = dateStr.substring(6, 8);
            const date = new Date(`${year}-${month}-${dayOfMonth}`);
            
            const options = { weekday: 'long', month: 'short', day: 'numeric' };
            const formattedDate = date.toLocaleDateString('en-US', options);
            
            const weatherDescriptions = {
                'clearday': 'Clear',
                'clearnight': 'Clear',
                'pcloudyday': 'Partly Cloudy',
                'pcloudynight': 'Partly Cloudy',
                'mcloudyday': 'Mostly Cloudy',
                'mcloudynight': 'Mostly Cloudy',
                'cloudyday': 'Cloudy',
                'cloudynight': 'Cloudy',
                'humidday': 'Humid',
                'humidnight': 'Humid',
                'lightrainday': 'Light Rain',
                'lightrainnight': 'Light Rain',
                'oshowerday': 'Occasional Showers',
                'oshowernight': 'Occasional Showers',
                'ishowerday': 'Isolated Showers',
                'ishowernight': 'Isolated Showers',
                'lightsnowday': 'Light Snow',
                'lightsnownight': 'Light Snow',
                'rainday': 'Rain',
                'rainnight': 'Rain',
                'snowday': 'Snow',
                'snownight': 'Snow',
                'rainsnowday': 'Rain/Snow',
                'rainsnownight': 'Rain/Snow',
                'tsrain': 'Thunderstorm with Rain',
                'tstorm': 'Thunderstorm',
                'windy': 'Windy'
            };
            
            const weatherDesc = weatherDescriptions[day.weather] || day.weather;
            const iconFile = `images/${weatherIcons[day.weather] || 'clear.png'}`;
            const tempUnit = currentUnit === 'fahrenheit' ? '°F' : '°C';
            
            const weatherCard = document.createElement('div');
            weatherCard.className = 'weather-card';
            weatherCard.innerHTML = `
                <div class="weather-date">${formattedDate}</div>
                <div class="weather-icon" style="background-image: url('${iconFile}')"></div>
                <div class="weather-temp">High: ${day.temp2m.max}${tempUnit}<br>Low: ${day.temp2m.min}${tempUnit}</div>
                <div class="weather-desc">${weatherDesc}</div>
                <div>Wind: ${day.wind10m_max} m/s</div>
                <a href="#" class="book-now">Book Now</a>
            `;
            
            weatherDisplay.appendChild(weatherCard);
        });
        
        weatherResults.appendChild(weatherDisplay);
        
        const sunnyDays = forecastData.filter(day => day.weather.includes('clear') || day.weather.includes('pcloudy')).length;
        if (sunnyDays >= 4) {
            const specialOffer = document.createElement('div');
            specialOffer.className = 'special-offer';
            specialOffer.innerHTML = `
                <h3>Sunny Destination Special!</h3>
                <p>${cityName} has ${sunnyDays} sunny days in the forecast!</p>
                <p>Book now and get 15% off your trip!</p>
            `;
            weatherResults.appendChild(specialOffer);
        }
        
        document.querySelectorAll('.book-now').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                alert(`Ready to book your trip to ${cityName}? Our travel specialists will contact you shortly!`);
            });
        });
        
        loadingElement.style.display = 'none';
    }
    
    function displaySampleData() {
        const sampleDataSeries = [];
        const today = new Date(); // Get today's date

        for (let i = 0; i < 7; i++) {
            const futureDate = new Date(today);
            futureDate.setDate(today.getDate() + i); // Add 'i' days to today

            // Format date toYYYYMMDD string for the 'date' property
            const year = futureDate.getFullYear();
            const month = String(futureDate.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
            const day = String(futureDate.getDate()).padStart(2, '0');
            const formattedDate = parseInt(`${year}${month}${day}`);

            // Use some varied weather conditions for sample data
            const sampleWeatherConditions = [
                "clearday", "pcloudyday", "mcloudyday", "lightrainday",
                "clearday", "oshowerday", "cloudyday"
            ];
            const sampleTemps = [
                {max: 22, min: 15}, {max: 20, min: 14}, {max: 19, min: 13},
                {max: 18, min: 12}, {max: 21, min: 14}, {max: 17, min: 11},
                {max: 20, min: 15}
            ];
            const sampleWinds = [3, 4, 5, 6, 4, 3, 4];

            sampleDataSeries.push({
                date: formattedDate,
                weather: sampleWeatherConditions[i],
                temp2m: sampleTemps[i],
                wind10m_max: sampleWinds[i]
            });
        }

        currentWeatherData = sampleDataSeries;
        // Only use " (Sample Data)" suffix if currentCityName is not set from CSV
        const displayName = currentCityName ? currentCityName + " (Sample Data)" : "Sample Data";
        displayWeather(currentWeatherData, displayName);
    }
    
    function clearWeatherResults() {
        weatherResults.innerHTML = '';
    }
    
    function showError(message) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
        loadingElement.style.display = 'none';
    }
});