 <!-- ***********************************************************************************
  Page Name  : current page name 
  Author     : Your Name 
  Your URL   : ocelot-aul.fiu/~__________
  Course     : CGS 4854 session, date, and time
  Program #  : Assignment #
  Purpose    : Describe what this page does 

  Due Date   : MM/DD/YYYY 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ your full name }..........
  ************************************************************************************* -->
<!DOCTYPE html>              <!-- this is a declaration used in HTML 5. It tells the browsers that this is HTML 5 -->
<html>                       <!-- start of html (Hyper Text Markup Language) -->

  <head>                     <!-- start of the head section -->
    <title>Contact_me.php</title>
  </head>                    <!-- end of the head section -->

  <body link="blue" vlink="blue" alink="red">                      <!-- start of the body section -->

    <?php  include( 'Haccandy_header.php' );  ?>
    <tr><td> &nbsp; </td> </tr>
    
    <center> <font color="red"><p><b>CONTACT ME</b></p> </font></center>
    
    <tr><td> &nbsp; </td> </tr>
    <?php  include( 'MainMenu.php' );  ?>
    
    <!--<tr><td> &nbsp; </td> </tr> -->

    <form method="POST" action="Contact_me_Controller.php">
      <div align="center" style="font-size: 20px;"><b></b></div>
       <tr><td> &nbsp; </td> </tr>
         <table style="width: 50%; margin: 0px auto; padding-right: 10%;">

           <!--  text type input  -->
           <tr>
             <td style="width: 5%; text-align: right;">Your Email &nbsp;</td>
             <td style="width: 20%;">
               <input type="text" name="YourEmail" value=" " style="width: 100%;">
             </td>
           </tr>

           <tr>
             <td style="width: 5%; text-align: right;">Last Name &nbsp;</td>
             <td style="width: 20%;">
               <input type="text" name="LastName" value=" " style="width: 100%;">
             </td>
           </tr>

           <tr>
             <td style="width: 5%; text-align: right;">First Name &nbsp;</td>
             <td style="width: 20%;">
               <input type="text" name="FirstName" value=" " style="width: 100%;">
             </td>
           </tr>

           <tr><td> &nbsp; </td> </tr>

           <!--  radio buttons  -->
           <tr>
             <td style="width: 5%; text-align: right;">Shipping &nbsp; </td>
             <td style="width: 20%; text-align: left;">
               <table style="margin: 0px auto;">
                 <tr>
                   <td text-align: left>
                     <input type="radio"
                            name="Shipping" value="Pick Up" > Pick Up &nbsp; &nbsp;
                     <input type="radio"
                            name="Shipping" value="Express" > Express &nbsp; &nbsp;
                    
                   </td>
                 </tr>
               </table>
             </td>
           </tr>

           <!-- CheckBoxes -->
           <tr>
             <td style="width: 5%; text-align: right">Hair Type  &nbsp; </td>
             <td style="width: 20%;">
               <table>
                 <tr>
                   <td><input type="checkbox" name="Malaysian" value="Malaysian" > Malaysian &nbsp;</td>

                   <td><input type="checkbox" name="Cambodian" value="Cambodian" > Cambodian &nbsp; &nbsp;</td>

                   <td><input type="checkbox" name="Indian" value="Indian" > Indian </td>
                 </tr>
               </table>
             </td>
           </tr>
           <tr><td> &nbsp; </td> </tr> 
         
           <!--  dropdown boxes -->
           <tr>
             <td style="width: 5%; text-align: right;">Edges  &nbsp;</td>
             <td style="width: 20%; text-align: left;">
               <select name="Dropdowns" style="width: 100%"size="1";>
                 <option value="Yes" >Yes </option>
                 <option value="No" >No </option>
               </select>
             </td>
           </tr>
           <tr><td> &nbsp; </td> </tr>            

           <!--  textarea box  -->
           <tr>
             <td style="width: 5%; text-align: right;">Comments &nbsp;</td>
             <td style="width: 20%;">
               <textarea name="Comments" rows="5" cols="42">
               </textarea><br>
             </td>
           </tr>
           <tr><td> &nbsp; </td> </tr>

           <tr>
             <td style="width: 15%;"> </td>
             <td style="width: 20%;" align=center>
             </td>
           </tr>

           <tr><td> &nbsp; </td> </tr>

            <tr>
               <td style="width: 15%;"> </td>
               <td style="width: 20%;" align=center>
                  <input type="submit" name="Submit"   value="Submit">&nbsp;
                  <input type="reset"  name="Clear"    value="Clear">
               </td>
            </tr>
            <tr><td> &nbsp; </td> </tr>
          </table>
        </form>
      </div>
      <?php  include( 'MainMenu.php' );  ?>
   </body>                    <!-- close of the body section -->

</html>                    <!-- close of html (Hyper Text Markup Language) -->

