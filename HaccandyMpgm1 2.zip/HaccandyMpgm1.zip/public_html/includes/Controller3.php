<!-- ***********************************************************************************
  Page Name  : current page name 
  Author     : Maria Chandy 
  Your URL   : ocelot-aul.fiu/~mhacc001
  Course     : CGS 4854 session, date, and time
  Program #  : Assignment #
  Purpose    : Describe what this page does 

  Due Date   : MM/DD/YYYY 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Maria Chandy }..........
  ************************************************************************************* -->

<html>

  <head>

    <title>

      Controller3.php

    </title>

    </head>

  <body>

    <?php
                     

       $connection = mysqli_connect("ocelot.aul.fiu.edu","spr23_mhacc001","6262270","spr23_mhacc001");
       if (mysqli_connect_errno())
       {
          echo "Failed to connect to MySQL: " . mysqli_connect_error();
       }
       else
       {  
             
             
          $dbName="spr23_mhacc001"; 
          $db_selected = mysqli_select_db( $connection, $dbName );
                      
          if (!$db_selected)
          {
             die( $dbName . ' does not exist, can\'t use it ' . mysqli_error());
          }
          else
          {
                   
             $tableName = "customers";
                      
             $query = mysqli_query( $connection, "SELECT * FROM $tableName" );
                     
             if(!$query)
             {
                        
                       
                $sql = "CREATE TABLE ".$tableName."(
                        Telephone VARCHAR(20) NOT NULL,
                        PRIMARY KEY(Telephone),
                        FirstName VARCHAR(35),
                        MiddleName VARCHAR(35),
                        LastName VARCHAR(35),
                        Email VARCHAR(100),
                        Address VARCHAR(100),
                        City VARCHAR(60), 
                        State  VARCHAR(50),
                        ZipCode  VARCHAR(15),
                        Type  VARCHAR(40),
                        Orders VARCHAR(400),
			SpecialNeeds VARCHAR(400),
			IT VARCHAR(2),
                        Cambodian VARCHAR(9),
                        Indian VARCHAR(6),
                        Malaysian VARCHAR(9)
                        )";
                                
                $result = mysqli_query( $connection, $sql );
                         
                if ($result)
                {

                }
                else
                {
                   die ("Can\'t create ". $tableName." ". mysqli_error() );
                }
                     
             } 
                        
          }
                
       }
       $Telephone  = $_POST['Telephone'];
       $FirstName  = $_POST['FirstName'];
       $MiddleName = $_POST['MiddleName'];
       $LastName  = $_POST['LastName'];
       $Email  = $_POST['Email'];
       $Address  = $_POST['Address'];
       $City  = $_POST['City'];
       $State  = $_POST['State'];
       $ZipCode = $_POST['ZipCode'];
       $Type   = $_POST['Type'];
       $Orders  = $_POST['Orders'];
       $SpecialNeeds  = $_POST['SpecialNeeds'];
       $IT  = $_POST['IT'];
       $Cambodian  = $_POST['Cambodian'];
       $Indian  = $_POST['Indian'];
       $Malaysian  = $_POST['Malaysian'];

       $found = $_POST['found'];                
               
          

       if ( $_POST['Find'] )
       { 
          include('Find.php');
          include( "Program3.php" );


       }              
       else if ( $_POST['Save'] )
       { 
          include('save.php');
          include( "Program3.php" );


       }
       else if ( $_POST['Modify'] )
       {  
          include('Modify.php');
          include( "Program3.php" );


       }
       else if ( $_POST['Delete'] )
       { 
          include('Delete.php');
          include( "Program3.php" );


       }
       else if ( $_POST['Clear'] )
       {
          include('Clear.php');
          include( "Program3.php" );


       }
       else if ( $_POST['Contact_Me'] )
       {
          include("Contact_me.php");
       }

       else
       { 
          echo "<br><h1> you pressed UNKOWN button</h1>";   
       }

       mysqli_close($connection); 
        
    ?>

  </body>

</html>



