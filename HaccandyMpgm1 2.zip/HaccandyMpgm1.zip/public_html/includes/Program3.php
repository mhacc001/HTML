<!-- ***********************************************************************************
  Page Name  : Program3.php
  Author     : Marie Haccandy
  Your URL   : ocelot-aul.fiu/~mhacc001
  Course     : CGS 4854 session, date, and time
  Program #  : Assignment #3
  Purpose    : - Create this assignment using an editor only, NO TEMPLATES OR IDES ALLOWED.
 - Extend your current website, creating the new pages described below, using HTML, 
   CSS and PHP

  Due Date   : MM/DD/YYYY 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{Marie Haccandy }..........
 ******************************************************************************* -->
<!DOCTYPE html>   <!-- declaration used in HTML 5. Tells browsers that this is HTML 5 -->

<html>
   <head>
      <title>Marie Haccandy-header.php</title>
      <link rel="stylesheet" type="text/css" href="css/style.css" />
   </head>

   <body style="margin: 0px; height: 100px;">
      <table style="width: 100%; margin: auto;">
         <br>
         <tr>
            <td style="width: 15%;" align="left">
            </td>
            <td style="width: 70%; color: #000064; font-size: 24px;"  align="center">
               <font face="Trebuchet MS">Marie's Hair Company</font>
            </td>

       	    <td style="width: 15%;" align="left">
               <!-- img src=" " class=" " alt=" " /-->
            </td>
         </tr>
      </table>
   </body>
</html>


      
<html>
   <head>
      <title>Marie Haccandy- pgm2.php</title>
      <link rel="stylesheet" type="text/css" href="css/style.css" />    
   </head>
          
   <body style="margin: 0px; height: 100px;">

<?php include('MainMenu.php') ?>

   <?php 
        
      if( strlen(trim($found)) > 0 )
      {  
         //echo "<br>Leave it alone  it means that find.php was already executed  Found = [" . $found . "]";
         //leave it alone it means that find.php was already executed 
      }
      else 
      {
         $found = ""; //set the value of $found to empty
      }

   ?>


   <br>
   <div>
      <form method="post" action="Controller3.php">
         <div align="center" style="font-size: 20px;"><b>Customer's Profile</b></div>
         <br>                                   
         <table style="width: 50%; margin: 0px auto; padding-right: 10%;">
                   
            <!--  text type input  -->
            <tr>
               <td style="width: 5%; text-align: right;">Telephone &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="Telephone" value="<?php echo $Telephone ?>" style="width: 100%;">
               </td>
            </tr>
<tr>
               <td style="width: 5%; text-align: right;">First Name &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="FirstName" value="<?php echo $FirstName ?>" style="width: 100%;">
               </td>
                </tr>
         <tr>
               <td style="width: 5%; text-align: right;">Middle Name &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="MiddleName" value="<?php echo $MiddleName ?>" style="width: 100%;">
               </td>
            </tr>  
            
            <tr>
               <td style="width: 5%; text-align: right;">Last Name &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="LastName" value="<?php echo $LastName ?>" style="width: 100%;">
               </td>
            </tr>

            
            <tr>
               <td style="width: 5%; text-align: right;">Email &nbsp; </td>
               <td style="width: 20%;">
                  <input id="Text" type="text" name="Email" value="<?php echo $Email ?>" style="width: 100%;">
               </td>
            </tr>

             <tr>
               <td style="width: 5%; text-align: right;">Address &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="Address" value="<?php echo $Address ?>" style="width: 100%;">
               </td>
            </tr>                                               
            <tr>
               <td style="width: 5%; text-align: right;">City &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="City" value="<?php echo $City ?>" style="width: 100%;">
               </td>
            </tr>
               <tr>
               <td style="width: 5%; text-align: right;">State &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="State" value="<?php echo $State ?>" style="width: 100%;">
               </td>
            </tr>
<tr>
               <td style="width: 5%; text-align: right;">Zip Code &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="Zip Code" value="<?php echo $ZipCode ?>" style="width: 100%;">
               </td>
            </tr>
            <tr><td> &nbsp; </td> </tr>
           
            <!--  dropdown boxes -->
            <tr>
               <td style="width: 5%; text-align: right;">type &nbsp; </td>
               <td style="width: 20%; text-align: left;">
                   <select name="Age" style="width: 100%"size="1";>
                        <option value="Classic virgin hair" <?php if ($type  == "Classic_virgin_hair") echo selected ?> >Classic virgin hair   </option>
                        <option value="Premium virgin hair" <?php if ($type  == "Premium_virgin_hair") echo selected ?> >Premium virgin hair   </option>
                        <option value="Luxurious virgin hair" <?php if ($type  == "Luxurious_virgin_hair") echo selected ?> >Luxurious virgin hair   </option>
                   </select>
               </td>
            </tr>
<tr><td> &nbsp; </td> </tr>            
            
            <!--  radio buttons  -->
            <tr>
               <td style="width: 5%; text-align: right;">Ship &nbsp; </td>
               <td style="width: 20%; text-align: left;">
                  <table style="margin: 0px auto;">
                     <tr>
                       <td text-align: left> 
                         <input type="radio" <?php if ($Ship == "Ship")   echo "checked"; ?> 
                                name="Ship" value="Ship" checked> Ship &nbsp; &nbsp;
                         <input type="radio" <?php if ($Ship == "Pick-up") echo "checked"; ?> 
                                name="Ship" value="Pick-up"> Pick-up &nbsp; &nbsp;
                        </td>
                     </tr>
                  </table>
               </td>
            </tr>
                             
            <tr><td> &nbsp; </td> </tr>                                         
                    
            <!-- CheckBoxes -->
            <tr>
              <td style="width: 5%; text-align: right">Preferences &nbsp; </td>
              <td style="width: 20%;">
                <table>
                  <tr>                                    
                    <td><input type="checkbox" name="Brazilian" 
                      <?php if ($Brazilian == "Brazilian") echo checked;?>  value="Brazilian" > IT &nbsp; &nbsp; </td>
                        
                    <td><input type="checkbox" name="Cambodian" 
                      <?php if ($Cambodian == "Cambodian") echo checked;?>  value="Cambodian" > Cambodian &nbsp; &nbsp; </td>
                      
                    <td><input type="checkbox" name="Indian" 
                      <?php if ($Indian == "Indian") echo checked;?>   value="Indian" > Indian &nbsp; &nbsp; </td>

                    <td><input type="checkbox" name="Malaysian" 
                      <?php if ($Malaysian == "Malaysian") echo checked;?>  value="Malaysian" > Malaysian  </td>
                  </tr>      
                </table>
              </td>
            </tr>
                 
            <!--  text type input  -->
            <tr>
               <td style="width: 5%; text-align: right;">Others &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="Others" value="<?php echo $Others ?>" style="width: 100%;">
               </td>
            </tr>
            
            <tr><td> &nbsp; </td> </tr>                              
              
            <!--  textarea box  -->
            <tr>
               <td style="width: 5%; text-align: left;">Special Needs &nbsp; </td>
               <td style="width: 20%;">
                 <textarea name="SpecialNeeds" rows="5" cols="42">
                   <?php echo $SpecialNeeds;?>
                 </textarea><br><br>
               </td>
            </tr>
               
            <tr><td> &nbsp; </td> </tr>                                                        
               
            <tr>
               <td style="width: 15%;"> </td>            
               <td style="width: 20%;" align=center>                
                   <?php echo $message ?>
               </td>
            </tr>
               
            <tr><td> &nbsp; </td> </tr>                                         

            <tr>
               <td style="width: 15%;"> </td>            
               <td style="width: 20%;" align=center> 
                  <input type="submit" name="Find"   value="Find">
                  <input type="submit" name="Save"   value="Save">
                  <input type="submit" name="Modify" value="Modify">
                  <input type="submit" name="Delete" value="Delete">
                  <input type="submit" name="Clear"  value="Clear">
		  <input type="submit" name="Contact_me"  value="Contact_me">
                  <input type="hidden" name="found"  value="<?php echo $found ?>" >  
               </td>
            </tr>
            
         </table>
      </form>
   </div>                       

   <?php include('MainMenu.php') ?>
 
   </body>
   
</html>




                      

