  <!-- ***********************************************************************************
  Page Name  : current page name 
  Author     : Your Name 
  Your URL   : ocelot-aul.fiu/~__________
  Course     : CGS 4854 session, date, and time
  Program #  : Assignment #
  Purpose    : Describe what this page does 

  Due Date   : MM/DD/YYYY 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ your full name }..........
  ************************************************************************************* -->
<!DOCTYPE html>   <!-- declaration used in HTML 5. Tells browsers that this is HTML 5 -->

<html>
  
  <body>

    <!--h3>this is find.phd</h3-->

    <?php

       $Telephone = trim($Telephone); 
       $sql="SELECT * FROM customers where Telephone = '$Telephone'";

       if ($result=mysqli_query($connection,$sql))
       {
          //printf("Result of mysqli_query(connection,sql) = %d<br>", $result);

          // Return the number of rows in result set
          $rowcount=mysqli_num_rows($result);

          //printf("Result set has %d rows.\n",$rowcount);
           
          while( $row = mysqli_fetch_array( $result ) )
          {
             $Telephone          = $row['Telephone'];      //primary key
             $Email              = $row['Email'];          //type="text"
             $FirstName          = $row['FirstName'];       //type="text"
             $MiddleName         = $row['MiddleName'];         //type="text"
             $LastName           = $row['LastName'];            //type="text"
             $Address            = $row['Address'];      //type="text"
             $City               = $row['City'];         //type="text"
             $State              = $row['State']; //type="text"
             $ZipCode            = $row['ZipCode']; //type="text"
             $Type               = $row['Type'];  //type="textarea"
             $Ship               = $row['Ship'];  //type="dropdown"
             $Preferences        = $row['Preferences']; //type="radio"
             $Others             = $row['Others'];       //type="checkbox"
             $SpecialNeeds       = $row['SpecialNeeds'];         //type="checkbox"
  
          }



          //printf("\ni am here in find.php\n [%s] [%s]", $Telephone, $FirstName );
          //echo "(".$Telephone." ".$FirstName.")";

          $Telephone=trim($Telephone); //take all front and back spaces out
     
          //if (mysqli_query($connection, $sql))
          if ( $rowcount )
          {
             $found = $Telephone;
             $message ="<span style=\"color: red;\">RECORD $found FOUND</span><br\>";
          }
          else if( strlen($Telephone) ==0 )
          {
             $message ="<span style=\"color: red;\">Telephone CAN NOT BE EMPTY</span><br>";
             //echo "<br>Error: " . $sql . " " . mysqli_error($connection);

             //clear data in variables       
             //$Telephone    = "";
             $Email          = "";
             $FirstName      = "";
             $MiddleName     = "";
             $LastName       = "";
             $Addres         = "";
             $City           = "";
             $State          = "";
             $ZipCode        = "";
             $Type           = "";
             $Ship           = "";
             $Preferences    = "";
             $Others         = "";
             $SpecialNeeds   = "";
       
             $found          = "";
          }
          else
          {
             $message ="<span style=\"color: red;\">RECORD $Telephone NOT FOUND</span><br>";
             //echo "<br>Error: " . $sql . " " . mysqli_error($connection);

            //clear data in variables
             //$Telephone    = "";
              $Email          = "";
             $FirstName      = "";
             $MiddleName     = "";
             $LastName       = "";
             $Addres         = "";
             $City           = "";
             $State          = "";
             $ZipCode        = "";
             $Type           = "";
             $Ship           = "";
             $Preferences    = "";
             $Others         = "";
             $SpecialNeeds   = "";

             $found          = "";
          }

      }
   ?>

  </body>

</html
