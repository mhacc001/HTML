<!-- ***********************************************************************************
  Page Name  : current page name 
  Author     : Your Name 
  Your URL   : ocelot-aul.fiu/~__________
  Course     : CGS 4854 session, date, and time
  Program #  : Assignment #
  Purpose    : Describe what this page does 

  Due Date   : MM/DD/YYYY 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ your full name }..........
  ************************************************************************************* -->

<!DOCTYPE html>   <!-- declaration used in HTML 5. Tells browsers that this is HTML 5 -->

<html>

  <body>

    <!--h3>this is modify.phd</h3-->

    <?php

       $Telephone = trim($Telephone);
       $found = $_POST['found'];
    

           
       if (  ( strlen(trim($found)) > 0 ) && ($found == $Telephone) )
       {
     
          $query = "UPDATE customers
                    SET Email           =  '$Email',
                        FirstName       =  '$FirstName',
                        Middlename      =  '$MiddleName',
                        LastName        =  '$LastName',
                        Address         =  '$Address' ,
                        City            =  '$City',
                        State       	=  '$State',
                        ZipCode         =  '$ZipCode',
                        Type            =  '$Type',
                        Ship            =  '$Ship',
                        IT              =  '$IT',
                        Cambodian       =  '$Cambodian',
                        Indian          =  '$Indian',
                        Malaysian       =  '$Malaysian',
                        Others          =  '$Others',
			SpecialNeeds    =  '$SpecialNeeds'
        
                   WHERE Telephone = '$Telephone'";

          $sql = mysqli_query( $connection,$query );

          if ($sql)
          {
             $message ="<span style=\"color: red;\">RECORD $found MODIFIED</span><br\>";
          }
          else
          {
             //echo "Problem updating record. MySQL Error: " . mysqli_error($connection);
             $message ="<span style=\"color: red;\">PROBLEM UPDATING RECORD</span><br\>";
          }

       }
       else
       {
          $message ="<span style=\"color: red;\">FIND THE RECORD BEFORE MODIFYING IT</span><br\>";
       }

    ?>

  </body>

</html>
