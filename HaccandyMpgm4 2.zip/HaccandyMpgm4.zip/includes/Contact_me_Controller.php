<!-- ***********************************************************************************
  Page Name  : current page name 
  Author     : Your Name 
  Your URL   : ocelot-aul.fiu/~__________
  Course     : CGS 4854 session, date, and time
  Program #  : Assignment #
  Purpose    : Describe what this page does 

  Due Date   : MM/DD/YYYY 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ your full name }..........
  ************************************************************************************* -->


<!DOCTYPE html>   <!-- declaration used in HTML 5. Tells browsers that this is HTML 5 -->

<html>
  <!--
  <head>
    <title>contact_me_controller</title>
  </head>
  -->

<body>
<font face="Courier">
<?php

if(isset($_POST['Submit'])) 
{ 
    $to          = "michael.robinson@cs.fiu.edu";
    $subject     = "From Marie Haccandy";
    $YourEmail   = $_POST['YourEmail'];
    $LastName    = $_POST['LastName'];
    $FirstName   = $_POST['FirstName'];
    $Shipping    = $_POST['Shipping']; 
    $Cambodian   = $_POST['Cambodian']; 
    $Indian      = $_POST['Indian']; 
    $Malaysian    = $_POST['Malaysian'];
    $Edges       = $_POST['Edges'];
    $Comments    = $_POST['Comments'];

    $body = " Your Email $YourEmail\n Last Name $LastName\n First Name $FirstName\n\n Shipping $Shipping\n Movie $LionKing $Dreamgirl $Epic\n\n Dropdowns $Dropdowns\n\n Comments $Comments";

    mail($to, $subject, $body);

    include('ContactMeSend.php');
    include('MainMenu.php');
}
else
{
  echo "<br><h1> Error!</h1>";
}

?>
</body>
</html>
