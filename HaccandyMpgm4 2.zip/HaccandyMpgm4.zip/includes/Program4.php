<!-- ***********************************************************************************
  Page Name  : current page name 
  Author     : Your Name 
  Your URL   : ocelot-aul.fiu/~__________
  Course     : CGS 4854 session, date, and time
  Program #  : Assignment #
  Purpose    : Describe what this page does 
 
  Due Date   : MM/DD/YYYY 
 
  Certification: 
 
  I hereby certify that this work is my own and none of it is the work of any other person. 
 
  ..........{ your full name }..........
  ************************************************************************************* -->
<!DOCTYPE html>              <!-- this is a declaration used in HTML 5. It tells the browsers that this is HTML 5 -->
<html>                       <!-- start of html (Hyper Text Markup Language) -->

  <head>                     <!-- start of the head section -->
    <title>HaccandyM_program4.php</title>

    <?php  include( 'haccandy_header.php' );  ?> <!-- calls the header page -->
    
    <style>
    .tooltip 
       {
        position: relative;
        display: inline-block;

       }

    .tooltip .tooltiptext 
       {
        visibility: hidden;
        width: 120px;
        background-color: green;
        color: #fff;
        text-align: center;
        border-radius: 6px;
        padding: 5px 0;
        position: absolute;
        z-index: 1;
        bottom: 125%;
        left: 50%;
        margin-left: -60px;
        opacity: 0;
        transition: opacity 1s;
       }


    .tooltip .tooltiptext .tooltip-left 
       {
        top: -5px;
        bottom:auto;
        right: 128%;  
       }



    .tooltip .tooltiptext::after 
       { 
        content: "";
        position: absolute;
        top: 100%;
        left: 50%;
        margin-left: -5px;
        border-width: 5px;
        border-style: solid;
        border-color: red transparent transparent transparent; /*arrow*/
       }

    .tooltip:hover .tooltiptext 
      {
        visibility: visible;
        opacity: 1;
      }

  </style>
    <tr><td> &nbsp; </td> </tr>
    
    <script>  
      function currentTime() 
      {
        var today   = new Date();
        var hour    = today.getHours();
        var minutes = today.getMinutes();
        var sec     = today.getSeconds();      
        minutes = checkTime(minutes);
        sec     = checkTime(sec);
           
        document.getElementById('txt').innerHTML = "Current Time : "+hour+":"+minutes+":"+sec;
        var t = setTimeout(function(){currentTime()},500);
      }
        function checkTime(i) 
        {
          if (i<10) {i = "0" + i};  // add zero in front of numbers < 10
          return i;
        }
      </script>
    </head>                    <!-- end of the head section -->
    
    <body onload="currentTime()">	<!-- start of body section-->
    
      <script>
      
      var temp1;
      function loggedInTime( temp )
      {
        var tiempo = new Date();  
        var temp2 =  "Logged in&nbsp;:&nbsp;" + tiempo;
        temp1 = temp2;
        document.write( temp2 );
      }
      //document.write( " " + "I am next " + temp1 ); 

      currentTime();
  
   </script>
   <center><table>
     <tr>
       <td style="width:60%; text-align: left;"><script>loggedInTime();</script></td>
       <td style="width:60%; text-align: right;"><div id="txt"></div></td>
       </tr>
    </table></center>
    
    <center> <font color="red"><p><b>Program 4</b></p> </font></center>
    <?php include(  'MainMenu.php');  ?> <!-- calls the main menu page -->
    <?php

      if( strlen(trim($found)) > 0 )
      {
         //echo "<br>Leave it alone  it means that find.php was already executed  Found = [" . $found . "]";
         //leave it alone it means that find.php was already executed
      }
      else
      {
         $found = ""; //set the value of $found to empty
      }

   ?>
    <tr><td> &nbsp; </td> </tr>
  <div>
  <!-- form which calls the Controller4-->
    <form method="post" action="Controller4.php">
      <div align="center" style="font-size: 20px;"><b></b></div>
      <table style="width: 50%; margin: 0px auto; padding-right: 10%;">

        <!--  text type input  -->
                 <!--  text type input  -->
            <tr>
               <td style="width: 5%; text-align: right;">Telephone &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="Telephone" value="<?php echo $Telephone ?>" style="width: 100%;">
               </td>
            </tr>
<tr>
               <td style="width: 5%; text-align: right;">First Name &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="FirstName" value="<?php echo $FirstName ?>" style="width: 100%;">
               </td>
                </tr>
         <tr>
               <td style="width: 5%; text-align: right;">Middle Name &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="MiddleName" value="<?php echo $MiddleName ?>" style="width: 100%;">
               </td>
            </tr>  
            
            <tr>
               <td style="width: 5%; text-align: right;">Last Name &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="LastName" value="<?php echo $LastName ?>" style="width: 100%;">
               </td>
            </tr>

            
            <tr>
               <td style="width: 5%; text-align: right;">Email &nbsp; </td>
               <td style="width: 20%;">
                  <input id="Text" type="text" name="Email" value="<?php echo $Email ?>" style="width: 100%;">
</td>
            </tr>

             <tr>
               <td style="width: 5%; text-align: right;">Address &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="Address" value="<?php echo $Address ?>" style="width: 100%;">
               </td>
            </tr>                                               
            <tr>
               <td style="width: 5%; text-align: right;">City &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="City" value="<?php echo $City ?>" style="width: 100%;">
               </td>
            </tr>
               <tr>
               <td style="width: 5%; text-align: right;">State &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="State" value="<?php echo $State ?>" style="width: 100%;">
               </td>
            </tr>
<tr>
               <td style="width: 5%; text-align: right;">Zip Code &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="Zip Code" value="<?php echo $ZipCode ?>" style="width: 100%;">
               </td>
            </tr>
            <tr><td> &nbsp; </td> </tr>
<!--  dropdown boxes -->
            <tr>
               <td style="width: 5%; text-align: right;">type &nbsp; </td>
               <td style="width: 20%; text-align: left;">
                   <select name="Age" style="width: 100%"size="1";>
                        <option value="Classic virgin hair" <?php if ($type  == "Classic_virgin_hair") echo selected ?> >Classic virgin hair   </option>
                        <option value="Premium virgin hair" <?php if ($type  == "Premium_virgin_hair") echo selected ?> >Premium virgin hair   </option>
                        <option value="Luxurious virgin hair" <?php if ($type  == "Luxurious_virgin_hair") echo selected ?> >Luxurious virgin hair   </option>
                   </select>
               </td>
            </tr>
<tr><td> &nbsp; </td> </tr>            
            
            <!--  radio buttons  -->
            <tr>
               <td style="width: 5%; text-align: right;">Ship &nbsp; </td>
               <td style="width: 20%; text-align: left;">
                  <table style="margin: 0px auto;">
                     <tr>
                       <td text-align: left> 
                         <input type="radio" <?php if ($Ship == "Ship")   echo "checked"; ?> 
                                name="Ship" value="Ship" checked> Ship &nbsp; &nbsp;
                         <input type="radio" <?php if ($Ship == "Pick-up") echo "checked"; ?> 
                                name="Ship" value="Pick-up"> Pick-up &nbsp; &nbsp;
                        </td>
                     </tr>
                  </table>
               </td>
            </tr>
                             
            <tr><td> &nbsp; </td> </tr>                                         
                    
            <!-- CheckBoxes -->
            <tr>
              <td style="width: 5%; text-align: right">Preferences &nbsp; </td>
              <td style="width: 20%;">
                <table>
                  <tr>                                    
                    <td><input type="checkbox" name="Brazilian" 
                      <?php if ($Brazilian == "Brazilian") echo checked;?>  value="Brazilian" > IT &nbsp; &nbsp; </td>
                        
                    <td><input type="checkbox" name="Cambodian" 
                      <?php if ($Cambodian == "Cambodian") echo checked;?>  value="Cambodian" > Cambodian &nbsp; &nbsp; </td>
                      
                    <td><input type="checkbox" name="Indian" 
                      <?php if ($Indian == "Indian") echo checked;?>   value="Indian" > Indian &nbsp; &nbsp; </td>

                    <td><input type="checkbox" name="Malaysian" 
                      <?php if ($Malaysian == "Malaysian") echo checked;?>  value="Malaysian" > Malaysian  </td>
                  </tr>      
                </table>
              </td>
            </tr>
           <!--  text type input  -->
            <tr>
               <td style="width: 5%; text-align: right;">Others &nbsp; </td>
               <td style="width: 20%;">
                  <input type="text" name="Others" value="<?php echo $Others ?>" style="width: 100%;">
               </td>
            </tr>
            
            <tr><td> &nbsp; </td> </tr>                              
              
            <!--  textarea box  -->
            <tr>
               <td style="width: 5%; text-align: left;">Special Needs &nbsp; </td>
               <td style="width: 20%;">
                 <textarea name="SpecialNeeds" rows="5" cols="42">
                   <?php echo $SpecialNeeds;?>
                 </textarea><br><br>
               </td>
            </tr>
               
            <tr><td> &nbsp; </td> </tr>                                                        
               
            <tr>
               <td style="width: 15%;"> </td>            
               <td style="width: 20%;" align=center>                
                   <?php echo $message ?>
               </td>
            </tr>
               
            <tr><td> &nbsp; </td> </tr>
<tr>
               <td style="width: 15%;"> </td>            
               <td style="width: 20%;" align=center> 
                  <input type="submit" name="Find"   value="Find">
                  <input type="submit" name="Save"   value="Save">
                  <input type="submit" name="Modify" value="Modify">
                  <input type="submit" name="Delete" value="Delete">
                  <input type="submit" name="Clear"  value="Clear">
                  <input type="submit" name="Contact_me"  value="Contact_me">
	       	<input type="submit" name="Help"  value="Help">
		  <input type="submit" name="About"  value="About">
                  <input type="hidden" name="found"  value="<?php echo $found ?>" >  
               </td>
            </tr>
            
         </table>
      </form>
   </div>                       
   <tr><td> &nbsp; </td></tr>
   <?php include('MainMenu.php') ?>
   <tr><td> &nbsp; </td></tr>
   </body>
   
</html>


