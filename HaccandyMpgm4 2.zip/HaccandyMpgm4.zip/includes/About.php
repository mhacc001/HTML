<!-- ***************************************************************************************
  Page Name  : includes/About.php
  Author     : Marie Haccandy
  Your URL   : ocelot-aul.fiu/~mhacc001
  Course     : WEB Online - CGS 4854, Fall 2022
  Program #4 : Assignment #4
  Purpose    : About section provides the purpose of the web page.

  Due Date   : 11/24/2022

  Certification:

  I hereby certify that this work is my own and none of it is the work of any other person.

  ..........Marie Haccandy..........
 **************************************************************************************** -->

<!DOCTYPE html>              


<html>
   <head>
  
    <style type="text/css">

    .helpHeadings1 /*Beyonce Questions*/ 
    { 
       font-family:sans-serif; 
       font-size:12pt;
       style="height:5px";
       color: pink;
       background-color:black;
    }

    .helpHeadings2 /*Results*/
    { 
       font-family:sans-serif; 
       font-size:12pt;
       style="height:5px";
       color: purple;
    }

    .helpHeadings3 /*Purpose*/
    { 
       font-family:sans-serif; 
       font-size:12pt;
       style="height:5px";
       color: red;
    }


    </style> 

    </head>

<body>


<div align="center">
   <h2 class="text-center">About Us</h2>
   <table width="75%" border="0"  BORDERCOLOR=blue  border-spacing: 15px; >
      <tr> 
         <td>
            <b>Marie Hair, as one of top manufacturer of hair products, was founded in 2022. We are dedicated to providing top quality virgin human hair for large trader and wholesaler.
 Usually they resell it to the retailers then to customers, which results in high price that makes customers awe-stricken.
 Although wholesaler can order cheap hair online, they headache a lot because of poor quality. However when you find Marie Hair mall, everything will be changed.
 We can help you solve all issues of the price and quality. Since 2023 our shopping mall is online, Marie hair has become the smart choice for thousands of women with its affordable price.
 According to data and statistics, 70% customers recommend us to their family and friends or return to order. 
99% wholesalers choose us as their only supplier (excluding some customize products we do not produce) after they find us. Because excellent quality hair make their business better and better.
 Marie body wave, deep wave, curly hair, loose wave, wet wavy, kinky straight and more charming sexy hairstyles always keep accompany with you on the way to beauty.:<br><br>


