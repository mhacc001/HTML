<!-- ***********************************************************************************
  Page Name  : current page name 
  Author     : Your Name 
  Your URL   : ocelot-aul.fiu/~__________
  Course     : CGS 4854 session, date, and time
  Program #  : Assignment #
  Purpose    : Describe what this page does 

  Due Date   : MM/DD/YYYY 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ your full name }..........
  ************************************************************************************* -->

<?php  include( 'Haccandy_header.php' );  ?>
<tr><td> &nbsp; </td> </tr>

<center> <font color="red"><p><b>CONTACT ME</b></p> </font></center>

<?php include(  'MainMenu.php');  ?>
<tr><td> &nbsp; </td> </tr>

<center> <font color="black"><p>Your message has been submitted to michael.robinson@cs.fiu.edu</p> </font></center>
<tr><td> &nbsp; </td> </tr>
<center> <font color="black"><p>thank you</p> </font></center>
