<!-- ***********************************************************************************
  Page Name  : current page name 
  Author     : Your Name 
  Your URL   : ocelot-aul.fiu/~__________
  Course     : CGS 4854 session, date, and time
  Program #  : Assignment #
  Purpose    : Describe what this page does 

  Due Date   : MM/DD/YYYY 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ your full name }..........
 ******************************************************************************* -->

<!DOCTYPE html>             
<html>                      

  <head>                     
    <title>controller2.php</title>
  </head>                    

  <body>                    

    This is controller2.php<br>
    Called from Program 2<br>

    <?php
//Creating data fiels to store data from website
   

       $Telephone      = $_POST['Telephone'];
       $FirstName      = $_POST['FirstName'];
       $MiddleName     = $_POST['MiddleName'];
       $Lastname       = $_POST['Lastname'];
       $Email          = $_POST['Email'];
       $Address        = $_POST['Address'];
       $City           = $_POST['City'];
       $State          = $_POST['State'];
       $ZipCode        = $_POST['ZipCode'];
       $Ship           = $_POST['Ship'];
       $IT             = $_POST['IT'];
       $Cambodian      = $_POST['Cambodian'];
       $Indian         = $_POST['Indian'];
       $Malaysian      = $_POST['Malaysian'];
       $Others         = $_POST['Others'];
       $SpecialNeeds   = $_POST['SpecialNeeds'];
//Displaying values from fields

       
       echo "Telephone $Telephone <br>";
       echo "First Name $Firstname <br>";
       echo "Middle Name $MiddleName <br>";
       echo "Last Name $LastName <br>";
       echo "Email $Email <br>";
       echo "Address $Address <br>";
       echo "City $City <br>";
       echo "State  $State <br>";
       echo "Zip Code  $Zip Code <br>";
       echo "Type $Type <br>";
       echo "Ship $Ship <br>";
       echo "IT $IT <br>";
       echo "Cambodian  $Cambodian <br>";
       echo "Indian $Indian <br>";
       echo "Malaysian $Malaydian <br>";
       echo "Others  $Others <br>";
       echo "Special Needs  $SpecialNeeds <br>";

//Creating button functions based on conditional  statements

if ( $_POST['Find'] )
       { 
          include('Find.php');
	  echo "You pressed the Find button";       
       }
       else if ( $_POST['Save'] )
       { 
          include('save.php');
          echo "You pressed the Save button"; 
       }
       else if ( $_POST['Modify'] )
       {  
          include('Modify.php');
          echo "You pressed the Modify button";
       }
       else if ( $_POST['Delete'] )
       { 
          include('Delete.php');
	  echo "You pressed the Delete button";
          
       }
       else if ( $_POST['Clear'] )
       {
          include('Clear.php');
	  echo "You pressed the Clear button";
         
       }
       else
       {
          echo "<br><h1> you pressed UNKNOWN button</h1>";
       }
   ?>                     

  </body>                 

</html>                    

