<!-- ***********************************************************************************
  Page Name  : current page name 
  Author     : Your Name 
  Your URL   : ocelot-aul.fiu/~__________
  Course     : CGS 4854 session, date, and time
  Program #  : Assignment #
  Purpose    : Describe what this page does 

  Due Date   : MM/DD/YYYY 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ your full name }..........
  ************************************************************************************* -->

<!DOCTYPE html>   <!-- declaration used in HTML 5. Tells browsers that this is HTML 5 -->

<html>

  <body>

    <!--br><h3>this is save.php</h3><br-->

    <?php

       $Telephone=trim($Telephone);
       if(strlen($Telephone)>0)
       {
          $sql="INSERT INTO customers (
                  Telephone,
                  Email,
                  FirstName,
                  MiddleName,
                  LastName,
                  Email,
                  Address,
                  City,
                  State,
                  ZipCode,
                  Type,
                  Ship,
                  IT,
                  Cambodian,
                  Indian,
                  Malaysian,
		  Others,
		  SpecialNeeds,
               )
               VALUES
               (
                  '$Telephone',
                  '$Email',
                  '$FirstName',
                  '$MiddleName',
                  '$LastName',
                  '$Address',
                  '$City',
                  '$State',
                  '$ZipCode',
                  '$Type',
                  '$Ship',
                  '$IT',
                  '$Cambodian',
                  '$Indian',
                  '$Malaysian',
                  '$Others',
		  '$Specialneeds',
               )";

          if (mysqli_query($connection, $sql))
          {
             //echo "<br>New record created successfully";
             $message ="<span style=\"color: red;\">RECORD $Telephone ADDED</span><br\>";
          }
          else
          {
             //echo "<br>Error: " . $sql . "<br>" . mysqli_error($connection);
             $message ="<span style=\"color: red;\">RECORD $Telephone EXISTS NOT ADDED</span><br\>";
          }

       }//end if(strlen($Telephone)>0)
       else
       {
          $message ="<span style=\"color: red;\">RECORD NOT ADDED<BR>Telephone CAN NOT BE EMPTY</span><br\>";
       }

    ?>

  </body>

</html>
